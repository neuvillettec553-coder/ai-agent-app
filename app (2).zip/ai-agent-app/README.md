# Agente de IA (custo zero) - v1.1

App web instalavel (PWA) para Android. Agente codador com loop Observar -> Raciocinar -> Agir, ferramentas, editor de .md e fallback automatico entre Gemini, Groq e OpenRouter (todos com cota gratuita).

## Paineis
- **Agente**: executa o loop e mostra cada passo em tempo real, com o caminho dos arquivos gravados.
- **Contexto**: edita agentes.md, memory.md, skills.md e os arquivos criados pelo agente (em agent-output/); renomeia, baixa tudo em ZIP e envia ao GitHub.
- **Playground**: testa as APIs (latencia e tokens) e roda JavaScript em sandbox.
- **Config**: chaves de API, modelos, token do GitHub e limite de passos.

## Novidades da v1.1
- Todo arquivo criado pelo agente vai para a pasta agent-output/.
- O caminho e aceito em varios nomes de campo (path, file, filename, arquivo, caminho).
- Gravacao sem caminho e recusada em vez de criar arquivo "undefined".
- A aba Contexto mostra caminhos completos, permite renomear e limpa registros antigos invalidos.
- O agente lista no final os arquivos realmente gravados.

## Publicacao automatica
Todo push na branch main compila e publica no GitHub Pages (workflow em .github/workflows/deploy.yml).
Configuracao unica: Settings > Pages > Source = GitHub Actions.

## Rodar localmente (opcional, Termux ou PC)
    npm install
    npm run dev

## Privacidade
Chaves e arquivos ficam no localStorage do navegador do aparelho. Nada e enviado a servidores proprios; as chamadas vao direto aos provedores de IA.
