import React, { useEffect, useState } from 'react';
import { CORE, PROJECT_ROOT, allFiles, buildZip, deleteFile, downloadBlob, groupByFolder, listFiles, readFile, renameFile, restoreDefault, writeFile } from '../lib/vfs';
import { pushFiles } from '../lib/github';
import { Settings } from '../types';

export function ContextScreen({ settings }: { settings: Settings }) {
  const [groups, setGroups] = useState<{ folder: string; names: string[] }[]>([]);
  const [cur, setCur] = useState('agentes.md');
  const [text, setText] = useState('');
  const [dirty, setDirty] = useState(false);
  const [msg, setMsg] = useState('');

  const refresh = () => setGroups(groupByFolder());
  const open = (name: string) => {
    setText(readFile(name));
    setCur(name);
    setDirty(false);
  };

  useEffect(() => {
    refresh();
    open('agentes.md');
  }, []);

  const save = () => {
    writeFile(cur, text);
    setDirty(false);
    setMsg('Salvo: ' + cur);
    refresh();
  };

  const create = () => {
    const name = window.prompt('Caminho do arquivo:', PROJECT_ROOT + '/index.html');
    if (!name) return;
    try {
      writeFile(name, '');
      refresh();
      open(name);
    } catch (e: any) {
      setMsg(e.message);
    }
  };

  const rename = () => {
    const to = window.prompt('Novo caminho para este arquivo:', cur);
    if (!to || to === cur) return;
    try {
      renameFile(cur, to);
      refresh();
      open(to.replace(/^\/+/, ''));
      setMsg('Renomeado para ' + to);
    } catch (e: any) {
      setMsg(e.message);
    }
  };

  const restore = () => {
    if (window.confirm('Restaurar o padrao de ' + cur + '? O conteudo atual sera perdido.')) {
      setText(restoreDefault(cur));
      setDirty(false);
    }
  };

  const remove = () => {
    if (!window.confirm('Apagar ' + cur + '?')) return;
    deleteFile(cur);
    refresh();
    open('agentes.md');
  };

  const sendGithub = async () => {
    try {
      setMsg('Iniciando envio...');
      await pushFiles(settings, allFiles(), setMsg);
    } catch (e: any) {
      setMsg('Erro: ' + e.message);
    }
  };

  return (
    <>
      <div className="chips">
        {groups.map((g) => (
          <React.Fragment key={g.folder}>
            {g.names.map((f) => (
              <button key={f} className={'chip' + (cur === f ? ' on' : '')} onClick={() => open(f)}>
                {f}
              </button>
            ))}
          </React.Fragment>
        ))}
        <button className="chip" onClick={create}>+ novo</button>
      </div>
      <p className="muted">
        {listFiles().length} arquivo(s). Os criados pelo agente ficam em <b>{PROJECT_ROOT}/</b>. O caminho completo aparece em cada botao e no log da aba Agente.
      </p>
      <textarea
        className="editor"
        value={text}
        spellCheck={false}
        autoCapitalize="none"
        onChange={(e) => { setText(e.target.value); setDirty(true); }}
      />
      <div className="row wrap">
        <button className="btn green" onClick={save}>{dirty ? 'Salvar *' : 'Salvar'}</button>
        {CORE.includes(cur) ? (
          <button className="btn amber" onClick={restore}>Restaurar padrao</button>
        ) : (
          <>
            <button className="btn amber" onClick={rename}>Renomear</button>
            <button className="btn red" onClick={remove}>Apagar</button>
          </>
        )}
        <button className="btn" onClick={() => downloadBlob(buildZip(), 'agente-arquivos.zip', 'application/zip')}>Baixar ZIP</button>
        <button className="btn dark" onClick={sendGithub}>Enviar ao GitHub</button>
      </div>
      {msg && <p className="muted">{msg}</p>}
    </>
  );
}
