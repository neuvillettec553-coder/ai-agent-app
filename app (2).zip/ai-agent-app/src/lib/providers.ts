import { LLMResult, Msg, ProviderId, Settings } from '../types';

export const ORDER: ProviderId[] = ['gemini', 'groq', 'openrouter'];
export const LABEL: Record<ProviderId, string> = {
  gemini: 'Google Gemini',
  groq: 'Groq',
  openrouter: 'OpenRouter',
};

export class ProviderError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

interface Opts {
  json?: boolean;
  signal?: AbortSignal;
  temperature?: number;
}

async function http(url: string, init: RequestInit, label: string): Promise<any> {
  let res: Response;
  try {
    res = await fetch(url, init);
  } catch (e: any) {
    if (e?.name === 'AbortError') throw e;
    throw new ProviderError(label + ': falha de rede', 0);
  }
  if (!res.ok) {
    const body = (await res.text()).slice(0, 200);
    throw new ProviderError(label + ' ' + res.status + ': ' + body, res.status);
  }
  return res.json();
}

export async function callProvider(
  id: ProviderId,
  s: Settings,
  system: string,
  msgs: Msg[],
  opts: Opts = {}
): Promise<LLMResult> {
  const key = s.keys[id].trim();
  const model = s.models[id].trim();
  if (!key) throw new ProviderError(LABEL[id] + ': sem chave', 401);
  const start = Date.now();
  const temperature = opts.temperature ?? 0.2;

  if (id === 'gemini') {
    const data = await http(
      'https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent',
      {
        method: 'POST',
        signal: opts.signal,
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: system }] },
          contents: msgs.map((m) => ({ role: m.role, parts: [{ text: m.text }] })),
          generationConfig: {
            temperature,
            ...(opts.json ? { responseMimeType: 'application/json' } : {}),
          },
        }),
      },
      LABEL[id]
    );
    const u = data.usageMetadata ?? {};
    const parts = data.candidates?.[0]?.content?.parts ?? [];
    return {
      text: parts.map((p: any) => p.text ?? '').join(''),
      latencyMs: Date.now() - start,
      promptTokens: u.promptTokenCount ?? 0,
      outputTokens: u.candidatesTokenCount ?? 0,
      totalTokens: u.totalTokenCount ?? 0,
      provider: id,
      model,
    };
  }

  // Groq e OpenRouter usam o formato compativel com OpenAI.
  const url =
    id === 'groq'
      ? 'https://api.groq.com/openai/v1/chat/completions'
      : 'https://openrouter.ai/api/v1/chat/completions';
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Authorization: 'Bearer ' + key,
  };
  if (id === 'openrouter') headers['X-Title'] = 'Agente de IA';
  const body: any = {
    model,
    temperature,
    messages: [
      { role: 'system', content: system },
      ...msgs.map((m) => ({ role: m.role === 'model' ? 'assistant' : 'user', content: m.text })),
    ],
  };
  // Ferramentas nativas desativadas: o app espera o JSON em texto, e alguns modelos
  // (gpt-oss) tentam emitir tool calls, o que gera erro 400 e derruba o provedor.
  if (opts.json) {
    if (id === 'groq') {
      body.response_format = { type: 'json_object' };
      body.tool_choice = 'none';
      body.parallel_tool_calls = false;
    } else {
      body.tool_choice = 'none';
    }
  }
  const data = await http(url, { method: 'POST', signal: opts.signal, headers, body: JSON.stringify(body) }, LABEL[id]);
  const u = data.usage ?? {};
  return {
    text: data.choices?.[0]?.message?.content ?? '',
    latencyMs: Date.now() - start,
    promptTokens: u.prompt_tokens ?? 0,
    outputTokens: u.completion_tokens ?? 0,
    totalTokens: u.total_tokens ?? 0,
    provider: id,
    model,
  };
}

export function availableProviders(s: Settings): ProviderId[] {
  return ORDER.filter((id) => s.keys[id].trim() !== '');
}

// Tenta cada provedor com chave, em ordem. Se um falhar (limite, rede, erro), passa ao proximo.
export async function callWithFallback(
  s: Settings,
  system: string,
  msgs: Msg[],
  opts: Opts = {},
  onFallback?: (msg: string) => void
): Promise<LLMResult> {
  const ids = availableProviders(s);
  if (ids.length === 0) throw new Error('Nenhuma chave de API configurada. Abra a aba Config.');
  const errors: string[] = [];
  for (const id of ids) {
    try {
      return await callProvider(id, s, system, msgs, opts);
    } catch (e: any) {
      if (e?.name === 'AbortError') throw e;
      errors.push(e?.message ?? String(e));
      onFallback?.(LABEL[id] + ' falhou (' + (e?.message ?? '').slice(0, 120) + '). Tentando o proximo...');
    }
  }
  throw new Error('Todos os provedores falharam:\n' + errors.join('\n'));
}
