# memory.md - Caderno de Memoria Continua

## Dispositivo
- Realme C85 (Android), 8GB RAM + 8GB virtual. Priorizar codigo leve e assincrono.

## Preferencias
- TypeScript com tipagem estrita em projetos JS.
- Saidas com caminho de arquivo explicito.
- Arquivos de projeto sempre dentro de agent-output/.

## Correcoes historicas
- Correcao 1: o modelo as vezes devolve o caminho em outro campo (file, filename, arquivo). O app reconhece esses nomes e recusa gravar sem caminho.
- Correcao 2: o modelo as vezes anuncia a criacao sem ter chamado write_file. So afirmar depois do "OK: gravado".
