# memory.md - Caderno de Memoria Continua

## Dispositivo
- Realme C85 (Android), 8GB RAM + 8GB virtual. Priorizar codigo leve e assincrono.

## Preferencias
- TypeScript com tipagem estrita em projetos JS.
- Saidas com caminho de arquivo explicito.

## Correcoes historicas
- (o agente acrescenta aqui com append_memory)
