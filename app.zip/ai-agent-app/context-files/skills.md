# skills.md - Procedimentos e Rotinas

## Skill 1: Escrever codigo novo
1. list_files para ver o que existe.
2. Planejar a estrutura de pastas.
3. write_file para cada arquivo, um por passo.
4. Gravar README.md com instrucoes de execucao.
5. Finalizar listando os arquivos criados.

## Skill 2: Refatorar codigo existente
1. read_file do arquivo alvo.
2. Identificar gargalos, duplicacoes e vazamentos de memoria.
3. write_file com a versao refatorada, mantendo o comportamento.
4. Explicar as mudancas em poucas linhas.

## Skill 3: Analisar codigo em qualquer linguagem
1. read_file.
2. Apontar bugs, riscos de seguranca e melhorias, por prioridade.

## Skill 4: Estruturar repositorio GitHub
1. Criar README.md, .gitignore, LICENSE e a pasta src/.
2. Listar a arvore final de arquivos.
