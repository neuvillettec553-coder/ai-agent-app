export type ProviderId = 'gemini' | 'groq' | 'openrouter';
export type StepType = 'OBSERVAÇÃO' | 'RACIOCÍNIO' | 'AÇÃO' | 'RESULTADO' | 'FINAL' | 'ERRO' | 'INFO';

export interface AgentStep {
  type: StepType;
  content: string;
  time: string;
}

export interface Msg {
  role: 'user' | 'model';
  text: string;
}

export interface LLMResult {
  text: string;
  latencyMs: number;
  promptTokens: number;
  outputTokens: number;
  totalTokens: number;
  provider: ProviderId;
  model: string;
}

export interface Settings {
  keys: Record<ProviderId, string>;
  models: Record<ProviderId, string>;
  github: { token: string; repo: string; branch: string; folder: string };
  maxIter: number;
}
