import React, { useState } from 'react';
import { LABEL, ORDER } from '../lib/providers';
import { ProviderId, Settings } from '../types';

const GUIDE: Record<ProviderId, { url: string; steps: string }> = {
  gemini: {
    url: 'https://aistudio.google.com/apikey',
    steps: 'Entre com sua conta Google, toque em "Create API key", copie a chave (comeca com AIza).',
  },
  groq: {
    url: 'https://console.groq.com/keys',
    steps: 'Crie uma conta, toque em "Create API Key", copie a chave (comeca com gsk_).',
  },
  openrouter: {
    url: 'https://openrouter.ai/keys',
    steps: 'Crie uma conta, toque em "Create Key", copie a chave (comeca com sk-or-). Use modelos com sufixo :free.',
  },
};

export function SettingsScreen({ settings, onChange }: { settings: Settings; onChange: (s: Settings) => void }) {
  const [show, setShow] = useState(false);
  const setKey = (id: ProviderId, v: string) => onChange({ ...settings, keys: { ...settings.keys, [id]: v } });
  const setModel = (id: ProviderId, v: string) => onChange({ ...settings, models: { ...settings.models, [id]: v } });
  const setGh = (k: keyof Settings['github'], v: string) => onChange({ ...settings, github: { ...settings.github, [k]: v } });

  return (
    <div className="scroll">
      <p className="muted">Tudo e salvo automaticamente, so neste aparelho. Basta uma chave; com mais de uma, o app troca sozinho se uma atingir o limite (ordem: Gemini, Groq, OpenRouter).</p>
      <label className="row"><input type="checkbox" checked={show} onChange={(e) => setShow(e.target.checked)} /> Mostrar chaves</label>

      {ORDER.map((id) => (
        <div key={id} className="card">
          <h3>{LABEL[id]}</h3>
          <p className="muted">
            <a href={GUIDE[id].url} target="_blank" rel="noreferrer">{GUIDE[id].url}</a><br />
            {GUIDE[id].steps}
          </p>
          <input
            type={show ? 'text' : 'password'}
            placeholder="Cole a chave aqui"
            value={settings.keys[id]}
            autoCapitalize="none"
            onChange={(e) => setKey(id, e.target.value)}
          />
          <input value={settings.models[id]} autoCapitalize="none" onChange={(e) => setModel(id, e.target.value)} />
          <span className="muted">Modelo (troque se o provedor renomear ou descontinuar)</span>
        </div>
      ))}

      <div className="card">
        <h3>GitHub (opcional)</h3>
        <p className="muted">
          Para enviar os arquivos do agente ao seu repositorio. Crie um token em github.com/settings/tokens (fine-grained, acesso so ao repositorio, permissao Contents: Read and write).
        </p>
        <input type={show ? 'text' : 'password'} placeholder="Token (github_pat_...)" value={settings.github.token} autoCapitalize="none" onChange={(e) => setGh('token', e.target.value)} />
        <input placeholder="usuario/repositorio" value={settings.github.repo} autoCapitalize="none" onChange={(e) => setGh('repo', e.target.value)} />
        <input placeholder="branch (main)" value={settings.github.branch} autoCapitalize="none" onChange={(e) => setGh('branch', e.target.value)} />
        <input placeholder="pasta de destino (agent-output)" value={settings.github.folder} autoCapitalize="none" onChange={(e) => setGh('folder', e.target.value)} />
      </div>

      <div className="card">
        <h3>Agente</h3>
        <label>Maximo de passos por tarefa: {settings.maxIter}</label>
        <input type="range" min={2} max={20} value={settings.maxIter} onChange={(e) => onChange({ ...settings, maxIter: Number(e.target.value) })} />
      </div>
    </div>
  );
}
