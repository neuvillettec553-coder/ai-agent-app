import React, { useEffect, useRef, useState } from 'react';
import { runAgent } from '../lib/agent';
import { availableProviders } from '../lib/providers';
import { AgentStep, Settings, StepType } from '../types';

const CLS: Record<StepType, string> = {
  'OBSERVAÇÃO': 'obs',
  'RACIOCÍNIO': 'rac',
  'AÇÃO': 'acao',
  RESULTADO: 'res',
  FINAL: 'final',
  ERRO: 'err',
  INFO: 'info',
};

export function AgentScreen({ settings, goConfig }: { settings: Settings; goConfig: () => void }) {
  const [task, setTask] = useState('');
  const [steps, setSteps] = useState<AgentStep[]>([]);
  const [running, setRunning] = useState(false);
  const [info, setInfo] = useState('');
  const abortRef = useRef<AbortController | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const hasKey = availableProviders(settings).length > 0;

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [steps.length]);
  useEffect(() => () => abortRef.current?.abort(), []);

  const start = async () => {
    if (!task.trim() || running) return;
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setSteps([]);
    setInfo('');
    setRunning(true);
    const t0 = Date.now();
    try {
      const r = await runAgent({
        task: task.trim(),
        settings,
        signal: ctrl.signal,
        onStep: (s) => setSteps((prev) => [...prev.slice(-199), s]),
      });
      setInfo(r.iterations + ' passo(s) - ' + r.tokens + ' tokens - ' + ((Date.now() - t0) / 1000).toFixed(1) + ' s');
    } catch (e: any) {
      const msg = ctrl.signal.aborted ? 'Execucao cancelada.' : e?.message ?? String(e);
      setSteps((prev) => [...prev, { type: 'ERRO', content: msg, time: new Date().toLocaleTimeString() }]);
    } finally {
      setRunning(false);
    }
  };

  return (
    <>
      <div className="scroll">
        {!hasKey && (
          <div className="card warn">
            Nenhuma chave de API configurada.{' '}
            <button className="link" onClick={goConfig}>Abrir Config</button>
          </div>
        )}
        {steps.length === 0 && !running && (
          <p className="muted">
            Descreva uma tarefa de programacao. O agente observa, raciocina e age com ferramentas. Os arquivos que ele cria aparecem na aba Contexto.
          </p>
        )}
        {steps.map((s, i) => (
          <div key={i} className={'step ' + CLS[s.type]}>
            <div className="tag">[{s.type}] {s.time}</div>
            <div className="body">{s.content}</div>
          </div>
        ))}
        {running && <p className="muted">Executando...</p>}
        {info && <p className="muted right">{info}</p>}
        <div ref={endRef} />
      </div>
      <div className="composer">
        <textarea
          rows={2}
          placeholder="O que voce quer programar ou refatorar?"
          value={task}
          onChange={(e) => setTask(e.target.value)}
        />
        {running ? (
          <button className="btn red" onClick={() => abortRef.current?.abort()}>Parar</button>
        ) : (
          <button className="btn" onClick={start}>Rodar</button>
        )}
      </div>
    </>
  );
}
