import React, { useState } from 'react';
import { LABEL, ORDER, callProvider, callWithFallback, availableProviders } from '../lib/providers';
import { runJs } from '../lib/sandbox';
import { LLMResult, ProviderId, Settings } from '../types';

type Row = { id: ProviderId; ok: boolean; text: string };

export function PlaygroundScreen({ settings }: { settings: Settings }) {
  const [choice, setChoice] = useState<'auto' | ProviderId>('auto');
  const [prompt, setPrompt] = useState('Escreva em Python uma funcao Fibonacci iterativa.');
  const [res, setRes] = useState<LLMResult | null>(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [rows, setRows] = useState<Row[]>([]);
  const [code, setCode] = useState('const a = [1,2,3].map(x => x * 2);\nconsole.log(a);');
  const [codeOut, setCodeOut] = useState('');

  const test = async () => {
    setBusy(true);
    setErr('');
    setRes(null);
    try {
      const sys = 'Voce e um assistente de programacao.';
      const msgs = [{ role: 'user' as const, text: prompt }];
      setRes(choice === 'auto' ? await callWithFallback(settings, sys, msgs) : await callProvider(choice, settings, sys, msgs));
    } catch (e: any) {
      setErr(e?.message ?? String(e));
    } finally {
      setBusy(false);
    }
  };

  const testAll = async () => {
    setBusy(true);
    setRows([]);
    const out: Row[] = [];
    for (const id of ORDER) {
      if (!settings.keys[id].trim()) {
        out.push({ id, ok: false, text: 'sem chave' });
      } else {
        try {
          const r = await callProvider(id, settings, 'Responda apenas: OK', [{ role: 'user', text: 'ping' }]);
          out.push({ id, ok: true, text: r.latencyMs + ' ms - ' + r.totalTokens + ' tokens (' + r.model + ')' });
        } catch (e: any) {
          out.push({ id, ok: false, text: e?.message ?? String(e) });
        }
      }
      setRows([...out]);
    }
    setBusy(false);
  };

  return (
    <div className="scroll">
      <h3>Conexoes</h3>
      <button className="btn" disabled={busy} onClick={testAll}>Testar todas as APIs</button>
      {rows.map((r) => (
        <div key={r.id} className={'card ' + (r.ok ? 'okc' : 'errc')}>
          <b>{LABEL[r.id]}</b>: {r.ok ? 'OK - ' : ''}{r.text}
        </div>
      ))}

      <h3>Testar prompt</h3>
      <select value={choice} onChange={(e) => setChoice(e.target.value as any)}>
        <option value="auto">Automatico (com fallback){availableProviders(settings).length ? '' : ' - sem chaves'}</option>
        {ORDER.map((id) => <option key={id} value={id}>{LABEL[id]}</option>)}
      </select>
      <textarea rows={4} value={prompt} onChange={(e) => setPrompt(e.target.value)} />
      <button className="btn" disabled={busy} onClick={test}>{busy ? 'Aguarde...' : 'Executar'}</button>
      {err && <p className="errtxt">{err}</p>}
      {res && (
        <>
          <div className="card">
            <b>{LABEL[res.provider]}</b> - {res.model}<br />
            Latencia: {res.latencyMs} ms<br />
            Tokens - entrada: {res.promptTokens} | saida: {res.outputTokens} | total: {res.totalTokens}
          </div>
          <pre className="card">{res.text}</pre>
        </>
      )}

      <h3>Sandbox JavaScript</h3>
      <textarea rows={5} className="mono" value={code} onChange={(e) => setCode(e.target.value)} />
      <button className="btn" onClick={async () => setCodeOut(await runJs(code))}>Executar codigo</button>
      {codeOut && <pre className="card">{codeOut}</pre>}
    </div>
  );
}
