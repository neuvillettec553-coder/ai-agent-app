import React, { useEffect, useState } from 'react';
import { CORE, allFiles, buildZip, deleteFile, downloadBlob, listFiles, readFile, restoreDefault, writeFile } from '../lib/vfs';
import { pushFiles } from '../lib/github';
import { Settings } from '../types';

export function ContextScreen({ settings }: { settings: Settings }) {
  const [files, setFiles] = useState<string[]>([]);
  const [cur, setCur] = useState('agentes.md');
  const [text, setText] = useState('');
  const [dirty, setDirty] = useState(false);
  const [msg, setMsg] = useState('');

  const refresh = () => setFiles(listFiles());
  const open = (name: string) => {
    setText(readFile(name));
    setCur(name);
    setDirty(false);
  };

  useEffect(() => {
    refresh();
    open('agentes.md');
  }, []);

  const save = () => {
    writeFile(cur, text);
    setDirty(false);
    setMsg('Salvo: ' + cur);
    refresh();
  };

  const create = () => {
    const name = window.prompt('Nome do arquivo (ex: projeto/src/main.py):');
    if (!name) return;
    try {
      writeFile(name, '');
      refresh();
      open(name.replace(/^\/+/, ''));
    } catch (e: any) {
      setMsg(e.message);
    }
  };

  const restore = () => {
    if (window.confirm('Restaurar o padrao de ' + cur + '? O conteudo atual sera perdido.')) {
      setText(restoreDefault(cur));
      setDirty(false);
    }
  };

  const remove = () => {
    if (!window.confirm('Apagar ' + cur + '?')) return;
    deleteFile(cur);
    refresh();
    open('agentes.md');
  };

  const sendGithub = async () => {
    try {
      setMsg('Iniciando envio...');
      await pushFiles(settings, allFiles(), setMsg);
    } catch (e: any) {
      setMsg('Erro: ' + e.message);
    }
  };

  return (
    <>
      <div className="chips">
        {files.map((f) => (
          <button key={f} className={'chip' + (cur === f ? ' on' : '')} onClick={() => open(f)}>{f}</button>
        ))}
        <button className="chip" onClick={create}>+ novo</button>
      </div>
      <textarea
        className="editor"
        value={text}
        spellCheck={false}
        autoCapitalize="none"
        onChange={(e) => { setText(e.target.value); setDirty(true); }}
      />
      <div className="row wrap">
        <button className="btn green" onClick={save}>{dirty ? 'Salvar *' : 'Salvar'}</button>
        {CORE.includes(cur) ? (
          <button className="btn amber" onClick={restore}>Restaurar padrao</button>
        ) : (
          <button className="btn red" onClick={remove}>Apagar</button>
        )}
        <button className="btn" onClick={() => downloadBlob(buildZip(), 'agente-arquivos.zip', 'application/zip')}>Baixar ZIP</button>
        <button className="btn dark" onClick={sendGithub}>Enviar ao GitHub</button>
      </div>
      {msg && <p className="muted">{msg}</p>}
    </>
  );
}
