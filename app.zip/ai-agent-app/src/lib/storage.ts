import { Settings } from '../types';

const KEY = 'agent.settings.v1';

export const DEFAULT_SETTINGS: Settings = {
  keys: { gemini: '', groq: '', openrouter: '' },
  models: {
    gemini: 'gemini-2.5-flash',
    groq: 'llama-3.3-70b-versatile',
    openrouter: 'openrouter/free',
  },
  github: { token: '', repo: '', branch: 'main', folder: 'agent-output' },
  maxIter: 8,
};

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const s = JSON.parse(raw);
    return {
      keys: { ...DEFAULT_SETTINGS.keys, ...s.keys },
      models: { ...DEFAULT_SETTINGS.models, ...s.models },
      github: { ...DEFAULT_SETTINGS.github, ...s.github },
      maxIter: s.maxIter || DEFAULT_SETTINGS.maxIter,
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(s: Settings) {
  localStorage.setItem(KEY, JSON.stringify(s));
}
