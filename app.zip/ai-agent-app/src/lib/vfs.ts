import { zipSync, strToU8 } from 'fflate';
import { DEFAULTS } from './defaults';

// Sistema de arquivos virtual no localStorage (limite do navegador: ~5 MB no total).
const P = 'vfs:file:';
const INDEX = 'vfs:index';
export const CORE = ['agentes.md', 'memory.md', 'skills.md'];

export function normalize(path: string): string {
  const p = path.replace(/\\/g, '/').replace(/^\/+/, '').trim();
  if (!p || p.split('/').some((s) => s === '..' || s === '')) throw new Error('Caminho invalido: ' + path);
  return p;
}

function getIndex(): string[] {
  try {
    return JSON.parse(localStorage.getItem(INDEX) || '[]');
  } catch {
    return [];
  }
}

export function ensureSeed() {
  for (const name of CORE) {
    if (localStorage.getItem(P + name) === null) localStorage.setItem(P + name, DEFAULTS[name]);
  }
}

export function listFiles(): string[] {
  ensureSeed();
  return [...CORE, ...getIndex().filter((f) => !CORE.includes(f)).sort()];
}

export function readFile(path: string): string {
  const p = normalize(path);
  ensureSeed();
  const v = localStorage.getItem(P + p);
  if (v === null) throw new Error('Arquivo nao encontrado: ' + p);
  return v;
}

export function writeFile(path: string, content: string) {
  const p = normalize(path);
  localStorage.setItem(P + p, content);
  const idx = getIndex();
  if (!CORE.includes(p) && !idx.includes(p)) localStorage.setItem(INDEX, JSON.stringify([...idx, p]));
}

export function deleteFile(path: string) {
  const p = normalize(path);
  if (CORE.includes(p)) throw new Error('Arquivos centrais nao podem ser apagados.');
  localStorage.removeItem(P + p);
  localStorage.setItem(INDEX, JSON.stringify(getIndex().filter((f) => f !== p)));
}

export function restoreDefault(name: string): string {
  if (!DEFAULTS[name]) throw new Error('Sem modelo padrao para ' + name);
  writeFile(name, DEFAULTS[name]);
  return DEFAULTS[name];
}

export function allFiles(): Record<string, string> {
  const out: Record<string, string> = {};
  for (const f of listFiles()) out[f] = readFile(f);
  return out;
}

export function buildZip(): Uint8Array {
  const data: Record<string, Uint8Array> = {};
  for (const [name, content] of Object.entries(allFiles())) {
    const path = CORE.includes(name) ? 'context-files/' + name : name;
    data[path] = strToU8(content);
  }
  return zipSync(data);
}

export function downloadBlob(bytes: Uint8Array, filename: string, mime: string) {
  const url = URL.createObjectURL(new Blob([bytes], { type: mime }));
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
