import { AgentStep, Msg, Settings, StepType } from '../types';
import { callWithFallback } from './providers';
import { runJs } from './sandbox';
import { ensureSeed, listFiles, readFile, writeFile } from './vfs';

const PROTOCOL = [
  'PROTOCOLO DE RESPOSTA (obrigatorio): responda SOMENTE com um objeto JSON, sem texto fora dele.',
  'Para usar uma ferramenta:',
  '{"observacao":"...","raciocinio":"...","acao":{"tool":"NOME","args":{...}}}',
  'Para encerrar:',
  '{"observacao":"...","raciocinio":"...","final":"resposta final ao usuario"}',
  'Ferramentas:',
  '- list_files: args {} - lista os arquivos.',
  '- read_file: args {"path":"..."} - le um arquivo.',
  '- write_file: args {"path":"projeto/src/x.py","content":"..."} - cria ou sobrescreve.',
  '- append_memory: args {"note":"..."} - acrescenta uma linha em memory.md.',
  '- run_js: args {"code":"..."} - executa JavaScript isolado e devolve o que foi impresso com console.log.',
  'Use uma ferramenta por resposta.',
].join('\n');

const now = () => new Date().toLocaleTimeString();

function parseJson(text: string): any {
  const a = text.indexOf('{');
  const b = text.lastIndexOf('}');
  if (a < 0 || b <= a) throw new Error('sem JSON');
  return JSON.parse(text.slice(a, b + 1));
}

async function runTool(tool: string, args: any): Promise<string> {
  switch (tool) {
    case 'list_files':
      return listFiles().join('\n');
    case 'read_file':
      return readFile(String(args?.path));
    case 'write_file':
      writeFile(String(args?.path), String(args?.content ?? ''));
      return 'OK: gravado ' + args?.path;
    case 'append_memory': {
      const cur = readFile('memory.md');
      writeFile('memory.md', cur.trimEnd() + '\n- ' + String(args?.note ?? '') + '\n');
      return 'OK: memoria atualizada';
    }
    case 'run_js':
      return runJs(String(args?.code ?? ''));
    default:
      throw new Error('Ferramenta desconhecida: ' + tool);
  }
}

export async function runAgent(p: {
  task: string;
  settings: Settings;
  onStep: (s: AgentStep) => void;
  signal?: AbortSignal;
}): Promise<{ tokens: number; iterations: number }> {
  const push = (type: StepType, content: string) => p.onStep({ type, content, time: now() });
  ensureSeed();
  const system = [readFile('agentes.md'), readFile('memory.md'), readFile('skills.md'), PROTOCOL].join('\n\n---\n\n');
  let msgs: Msg[] = [{ role: 'user', text: 'TAREFA: ' + p.task }];
  const max = p.settings.maxIter || 8;
  let tokens = 0;

  for (let i = 1; i <= max; i++) {
    if (p.signal?.aborted) throw new Error('Cancelado');
    const r = await callWithFallback(p.settings, system, msgs, { json: true, signal: p.signal }, (m) => push('INFO', m));
    tokens += r.totalTokens;
    if (i === 1) push('INFO', 'Provedor: ' + r.provider + ' (' + r.model + ')');

    let obj: any;
    try {
      obj = parseJson(r.text);
    } catch {
      push('ERRO', 'Resposta fora do formato JSON; pedindo novamente.');
      msgs.push({ role: 'model', text: r.text }, { role: 'user', text: 'Resposta invalida. Responda somente com o JSON do protocolo.' });
      continue;
    }

    if (obj.observacao) push('OBSERVAÇÃO', String(obj.observacao));
    if (obj.raciocinio) push('RACIOCÍNIO', String(obj.raciocinio));

    if (typeof obj.final === 'string') {
      push('FINAL', obj.final);
      return { tokens, iterations: i };
    }

    const tool = obj.acao?.tool;
    if (!tool) {
      msgs.push({ role: 'model', text: r.text }, { role: 'user', text: 'Informe uma acao (tool) ou o campo final.' });
      continue;
    }

    push('AÇÃO', tool + ' ' + JSON.stringify(obj.acao.args ?? {}).slice(0, 400));
    let result: string;
    try {
      result = await runTool(tool, obj.acao.args);
    } catch (e: any) {
      result = 'ERRO: ' + (e?.message ?? String(e));
    }
    push('RESULTADO', result.slice(0, 600));
    msgs.push({ role: 'model', text: r.text }, { role: 'user', text: 'RESULTADO DA FERRAMENTA:\n' + result.slice(0, 6000) });

    // Janela deslizante: mantem a memoria e o consumo de tokens sob controle.
    if (msgs.length > 17) msgs = [msgs[0], ...msgs.slice(-14)];
  }

  push('ERRO', 'Limite de iteracoes atingido (' + max + ').');
  return { tokens, iterations: max };
}
