import React, { useState } from 'react';
import { AgentScreen } from './screens/AgentScreen';
import { ContextScreen } from './screens/ContextScreen';
import { PlaygroundScreen } from './screens/PlaygroundScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { loadSettings, saveSettings } from './lib/storage';
import { Settings } from './types';

const TABS = [
  { key: 'agent', label: 'Agente' },
  { key: 'context', label: 'Contexto' },
  { key: 'play', label: 'Playground' },
  { key: 'config', label: 'Config' },
] as const;

export function App() {
  const [tab, setTab] = useState<(typeof TABS)[number]['key']>('agent');
  const [settings, setSettings] = useState<Settings>(loadSettings);

  const update = (s: Settings) => {
    setSettings(s);
    saveSettings(s);
  };

  // As telas ficam montadas (so escondidas) para nao perder o estado ao trocar de aba.
  const pane = (k: string) => ({ display: tab === k ? 'flex' : 'none' } as const);

  return (
    <div className="app">
      <main>
        <section className="pane" style={pane('agent')}><AgentScreen settings={settings} goConfig={() => setTab('config')} /></section>
        <section className="pane" style={pane('context')}><ContextScreen settings={settings} /></section>
        <section className="pane" style={pane('play')}><PlaygroundScreen settings={settings} /></section>
        <section className="pane" style={pane('config')}><SettingsScreen settings={settings} onChange={update} /></section>
      </main>
      <nav>
        {TABS.map((t) => (
          <button key={t.key} className={tab === t.key ? 'on' : ''} onClick={() => setTab(t.key)}>
            {t.label}
          </button>
        ))}
      </nav>
    </div>
  );
}
