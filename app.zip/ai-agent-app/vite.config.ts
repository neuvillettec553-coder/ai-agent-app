import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base relativo: funciona em qualquer nome de repositorio no GitHub Pages.
export default defineConfig({
  base: './',
  plugins: [react()],
  build: { target: 'es2020' },
});
