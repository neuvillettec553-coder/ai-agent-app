# Agente de IA (custo zero)

App web instalavel (PWA) para Android. Agente codador com loop Observar -> Raciocinar -> Agir, ferramentas, editor de .md e fallback automatico entre Gemini, Groq e OpenRouter (todos com cota gratuita).

## Paineis
- **Agente**: executa o loop e mostra cada passo em tempo real.
- **Contexto**: edita agentes.md, memory.md, skills.md e os arquivos criados pelo agente; baixa tudo em ZIP; envia ao GitHub.
- **Playground**: testa as APIs (latencia e tokens), testa codigo JavaScript em sandbox.
- **Config**: chaves de API, modelos e token do GitHub (ficam so no seu aparelho).

## Publicacao automatica
Todo push na branch main compila e publica no GitHub Pages (workflow em .github/workflows/deploy.yml).
Configuracao unica: Settings > Pages > Source = GitHub Actions.

## Rodar localmente (opcional, Termux ou PC)
    npm install
    npm run dev

## Privacidade
Chaves e arquivos ficam no localStorage do navegador do aparelho. Nada e enviado a servidores proprios; as chamadas vao direto aos provedores de IA.
